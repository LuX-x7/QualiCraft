Frozen researcher-authored QT report. Figure captions are editable; figures and counts are saved outputs.
Each figures/<id>/ folder contains the exact CSV and figure.py used for its PNG, SVG and PDF. Install matplotlib (and scipy when clustering is selected), then run python figure.py inside that folder. Font and package versions affect cross-environment rendering.
report.json preserves the report and its shared figure records, not the full source project. Export project JSON separately for QT restoration. Word edits do not update QT.
